# EKIP — API Documentation

Base URL: `/api`. All authenticated endpoints require an `Authorization: Bearer <accessToken>` header unless noted. Responses are JSON. Errors follow:

```json
{ "error": { "code": "STRING_CODE", "message": "Human-readable message" } }
```

---

## Auth

### `POST /api/auth/signup`
Creates a Supabase identity + mirrored MongoDB user (`status: "invited"` unless self-signup is enabled for the org's email domain).
```json
// Request
{ "name": "Priya Shah", "email": "priya@company.com", "password": "••••••••" }
// Response 201
{ "userId": "...", "email": "priya@company.com", "status": "invited" }
```

### `POST /api/auth/login`
```json
// Request
{ "email": "priya@company.com", "password": "••••••••" }
// Response 200 (also sets HttpOnly refresh cookie)
{ "accessToken": "...", "user": { "id": "...", "name": "Priya Shah", "role": "employee", "department": "HR" } }
```

### `POST /api/auth/refresh`
No body — refresh cookie is read server-side. Returns a new `accessToken`.

### `POST /api/auth/logout`
Clears the refresh cookie and revokes the Supabase session.

### `POST /api/auth/forgot-password` / `POST /api/auth/reset-password`
Proxies to Supabase Auth's password-recovery flow.

---

## Chat / RAG

### `POST /api/chat/ask`
```json
// Request
{ "conversationId": "optional-existing-id", "question": "What is the reimbursement policy for international travel?" }
// Response 200
{
  "conversationId": "...",
  "messageId": "...",
  "answer": "Employees are reimbursed for international travel up to ₹80,000 per trip, subject to pre-approval.",
  "citations": [
    { "documentId": "...", "documentName": "Travel_Policy.pdf", "page": 4, "chunkId": "..." }
  ],
  "confidence": 0.93
}
```
If no permitted, relevant chunk clears the retrieval threshold, `answer` explains that no grounded answer was found rather than guessing, and `citations` is `[]`.

### `POST /api/chat/messages/:messageId/feedback`
```json
{ "rating": "up" }  // or "down"
```

### `GET /api/chat/conversations` — list current user's conversations (paginated).
### `GET /api/chat/conversations/:id` — full message history for one conversation.
### `PATCH /api/chat/conversations/:id` — rename / archive.
### `DELETE /api/chat/conversations/:id`

---

## Documents

### `GET /api/documents` — list, filterable by `department`, `securityLevel`, `status`, `tag`, permission-filtered to the caller automatically.
### `GET /api/documents/search?q=...` — semantic search (embeds `q`, runs `$vectorSearch`, groups results by parent document).
### `GET /api/documents/:id` — metadata + signed URL to preview (only if caller is permitted).
### `POST /api/documents` — **Admin only.** Multipart upload.
```json
// Request (multipart/form-data): file, department, securityLevel, allowedRoles[], tags[]
// Response 202
{ "documentId": "...", "status": "queued" }
```
### `GET /api/documents/:id/status` — ingestion status (`queued`/`processing`/`ready`/`failed`).
### `POST /api/documents/:id/reprocess` — **Admin only.**
### `DELETE /api/documents/:id` — **Admin only.**
### `POST /api/documents/:id/summarize`
```json
// Response 200
{ "purpose": "Vendor Agreement", "keyPoints": ["Payment terms: net-30", "Termination: 60-day notice"], "riskFlag": "medium" }
```

---

## Permissions

### `GET /api/documents/:id/permissions` — **Admin only.** Lists role/user grants.
### `POST /api/documents/:id/permissions` — **Admin only.**
```json
{ "grantType": "user", "userId": "...", "accessLevel": "view" }
```
### `DELETE /api/documents/:id/permissions/:permissionId` — **Admin only.**

---

## Users (Admin console)

### `GET /api/users` — **Admin only.** Paginated, filterable by department/role/status.
### `POST /api/users/invite` — **Admin only.**
### `PATCH /api/users/:id` — **Admin only.** Update role, department, status.
### `DELETE /api/users/:id` — **Admin only.** Soft-delete (`status: "suspended"`).

---

## Analytics

### `GET /api/analytics/department` — **Manager, Admin.** Query volume, top topics, feedback rate, scoped to the caller's department for Managers, org-wide for Admins.
### `GET /api/analytics/evaluation` — **Admin only.** Retrieval precision samples, hallucination review queue size, confidence distribution.

---

## Audit

### `GET /api/audit` — **Admin only.** Filterable by `actorId`, `targetType`, `action`, date range. Paginated.

---

## System / health

### `GET /api/health` — liveness/readiness for the API tier (no auth).
### `GET /api/ingestion/queue` — **Admin only.** Current queue depth and per-job stage, for the ingestion monitor page.

---

## Common error codes

| Code | Meaning |
|---|---|
| `AUTH_INVALID_CREDENTIALS` | Login failed |
| `AUTH_TOKEN_EXPIRED` | Access token expired — client should call `/api/auth/refresh` |
| `AUTH_FORBIDDEN` | Authenticated but role/permission does not allow this action |
| `DOCUMENT_NOT_FOUND` | Document does not exist or caller has no visibility into it (identical response for both, to avoid leaking existence of restricted docs) |
| `INGESTION_FAILED` | Document processing failed — see `processingError` on the document record |
| `RATE_LIMITED` | Too many requests in the current window |
| `VALIDATION_ERROR` | Malformed request body |
